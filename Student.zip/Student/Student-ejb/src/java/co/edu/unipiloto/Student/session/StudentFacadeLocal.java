package co.edu.unipiloto.Student.session;

import co.edu.unipiloto.Student.Estudent;
import java.util.List;
import javax.ejb.Local;

@Local
public interface StudentFacadeLocal {

    void create(Estudent student);

    void edit(Estudent student);

    void remove(Estudent student);

    Estudent find(Object id);

    List<Estudent> findAll();

    List<Estudent> findRange(int[] range);

    int count();
    
}
